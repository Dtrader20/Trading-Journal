DIARIO DE TRADING — APP ANDROID NATIVA (offline)
=================================================

Esta carpeta es el proyecto Android completo. Dentro de app/src/main/assets/
va index.html: tu diario de trading con todas las funciones (Exchange %,
Wallet, gráficos). La app instala ese diario como app nativa, 100% offline,
y los datos quedan guardados en el teléfono.

CÓMO COMPILAR EL APK SOLO CON EL TELÉFONO (GitHub gratis)
----------------------------------------------------------
1. Descarga el archivo diario-trading-android.zip desde el chat de Thaura.

2. En el navegador del teléfono entra a github.com e inicia sesión.
   Toca el símbolo "+" → "New repository".
   Nombre: diario-trading   |   Visibilidad: Public   → "Create repository".

3. En la página del repositorio nuevo, toca "creating a new file"
   (o el botón "Add file" → "Create new file").
   En el nombre del archivo escribe exactamente:
       .github/workflows/build.yml
   (al poner las barras, GitHub crea las carpetas solo).
   Pega el contenido del archivo build.yml que está dentro del zip
   (ábrelo con la app Archivos → carpeta .github → workflows).
   Toca "Commit changes".

4. Vuelve a la página del repositorio → "Add file" → "Upload files".
   Sube el zip diario-trading-android.zip completo → "Commit changes".
   Eso dispara la compilación automática.

5. Ve a la pestaña "Actions": verás "Compilar APK" en marcha.
   La primera vez tarda 5-10 minutos. Cuando termine con ✓, ábrela y
   en la sección "Artifacts" descarga "DiarioTrading-APK".

6. El artifact baja como zip: extráelo con la app Archivos y toca el
   app-debug.apk para instalarlo (te pedirá permitir "fuentes
   desconocidas": es normal en toda app fuera de Play Store).

¿CUÁNTO CUESTA?
---------------
Nada. Los repositorios públicos tienen GitHub Actions gratis e ilimitado.
Incluso en un repo privado tienes 2.000 minutos gratis al mes y esta
compilación usa unos 5.

PARA ACTUALIZAR LA APP
----------------------
Cambia lo que quieras (o pídeme cambios) y vuelve a subir el zip:
cada subida compila un APK nuevo. El número de versión se cambia en
app/build.gradle (versionCode y versionName).

NOTAS
-----
- El botón "Exportar datos" de la app guarda el respaldo en la carpeta
  Descargas del teléfono.
- Los datos viven en la app: si la desinstalas se borran, así que exporta
  el respaldo de vez en cuando.
